for i, force in pairs(game.forces) do
    force.technologies["logistics"].hidden = true
    force.technologies["logistics-2"].hidden = true
    force.technologies["logistics-3"].hidden = true
end