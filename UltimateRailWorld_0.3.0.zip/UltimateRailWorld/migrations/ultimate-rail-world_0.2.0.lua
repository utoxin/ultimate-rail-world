for i, force in pairs(game.forces) do
    force.technologies["logistic-robotics"].enabled = true
end